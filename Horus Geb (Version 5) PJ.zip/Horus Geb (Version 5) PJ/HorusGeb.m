% nD = 1000;
% Dlower = 5;
% Dupper = 64000;
% nV = 46;
% Vlower = 10;
% Vupper = 56;
% nAngles = 90;
% AtmosphereMultiplier = 0.1;
nD = 20;
Dlower = 100;
Dupper = 64000;
nV = 20;
Vlower = 10;
Vupper = 56;
nAngles = 20;
AtmosphereMultiplier = 1;


%
%% To plot the histogram with BA:
SurfaceAge=100;
stats = plotVenusHistogram_BA(nD,Dlower,Dupper,nV,Vlower,Vupper,nAngles,AtmosphereMultiplier,SurfaceAge);
stats1=stats(stats(:,12)>0 & ~isnan(stats(:,12)),:);

%% To plot the histogram with LW:
SurfaceAge=800;
stats = plotVenusHistogram_LW(nD,Dlower,Dupper,nV,Vlower,Vupper,nAngles,AtmosphereMultiplier,SurfaceAge);
stats1=stats(stats(:,12)>0 & ~isnan(stats(:,12)),:);

%%
% % To get the crater stats:
% parallel = 1;
% stats = VenusCraterSimulation(nD,Dlower,Dupper,...
%     nV,Vlower,Vupper,nAngles,AtmosphereMultiplier,parallel);